import React, { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { TrendingUp, AlertTriangle, Package, DollarSign, PieChart, PlusCircle, Trash2, Download } from "lucide-react";

// ---------- Helpers ----------
const MATERIALS = [
  { key: "flour", label: "Flour (kg)", threshold: 5 },
  { key: "sugar", label: "Sugar (kg)", threshold: 5 },
  { key: "oil", label: "Oil (kg)", threshold: 3 },
  { key: "eggs", label: "Eggs (pcs)", threshold: 24 },
  { key: "bakingPowder", label: "Baking Powder (g)", threshold: 200 },
  { key: "vanilla", label: "Vanilla (ml)", threshold: 50 },
  { key: "milk", label: "Milk (L)", threshold: 2 },
  { key: "water", label: "Water (L)", threshold: 5 },
  { key: "glucose", label: "Glucose (kg)", threshold: 1 },
];

const PRODUCTS = ["Cake", "Biscuit"];

const LS = { stock: "rb_stock", sales: "rb_sales", expenses: "rb_expenses" };

function readLS(key, fallback) {
  try { const raw = localStorage.getItem(key); return raw ? JSON.parse(raw) : fallback; } catch { return fallback; }
}
function writeLS(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); } catch {}
}

export default function App() {
  const [tab, setTab] = useState("Dashboard");

  const [stock, setStock] = useState(() =>
    readLS(LS.stock, MATERIALS.reduce((acc, m) => ({ ...acc, [m.key]: 0 }), {}))
  );
  const [sales, setSales] = useState(() => readLS(LS.sales, []));
  const [expenses, setExpenses] = useState(() => readLS(LS.expenses, []));

  useEffect(() => writeLS(LS.stock, stock), [stock]);
  useEffect(() => writeLS(LS.sales, sales), [sales]);
  useEffect(() => writeLS(LS.expenses, expenses), [expenses]);

  const totals = useMemo(() => {
    const revenue = sales.reduce((s, r) => s + r.qty * r.unitPrice, 0);
    const expense = expenses.reduce((s, e) => s + e.amount, 0);
    const profit = revenue - expense;
    return { revenue, expense, profit };
  }, [sales, expenses]);

  const bestSeller = useMemo(() => {
    const map = new Map();
    sales.forEach((s) => map.set(s.product, (map.get(s.product) || 0) + s.qty));
    let top = null;
    for (const [p, q] of map.entries()) if (!top || q > top.qty) top = { product: p, qty: q };
    return top;
  }, [sales]);

  const lowStock = useMemo(
    () => MATERIALS.filter((m) => (stock[m.key] ?? 0) <= m.threshold),
    [stock]
  );

  const aiInsights = useMemo(() => {
    const tips = [];
    if (bestSeller) tips.push(`Consider increasing production for ${bestSeller.product} (demand: ${bestSeller.qty}).`);
    else tips.push("Log a few sales to unlock demand insights.");
    if (lowStock.length) {
      const names = lowStock.map((m) => m.label.split(" ")[0]).join(", ");
      tips.push(`Low stock detected: ${names}. Reorder soon.`);
    }
    if (totals.expense > 0 && totals.revenue === 0) tips.push("Expenses recorded without sales. Add sales or review cost controls.");
    if (totals.revenue > 0 && totals.profit / Math.max(1, totals.revenue) < 0.1) tips.push("Profit margin under 10%. Review pricing or reduce costs.");
    return tips;
  }, [bestSeller, lowStock, totals]);

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur border-b">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Package className="w-6 h-6" />
            <h1 className="font-semibold text-xl">Royal Bakery – Backoffice (Prototype)</h1>
          </div>
          <nav className="flex gap-2">
            {["Dashboard","Sales","Expenses","Stock","Reports","Settings"].map((t) => (
              <button key={t} onClick={() => setTab(t)}
                className={`px-3 py-1.5 rounded-2xl text-sm border transition ${tab === t ? "bg-gray-900 text-white" : "bg-white hover:bg-gray-100"}`}>
                {t}
              </button>
            ))}
          </nav>
        </div>
      </header>

      <main className="max-w-5xl mx-auto p-4">
        {tab === "Dashboard" && (<Dashboard totals={totals} aiInsights={aiInsights} lowStock={lowStock} />)}
        {tab === "Sales" && (<SalesPage sales={sales} setSales={setSales} />)}
        {tab === "Expenses" && (<ExpensesPage expenses={expenses} setExpenses={setExpenses} />)}
        {tab === "Stock" && (<StockPage stock={stock} setStock={setStock} />)}
        {tab === "Reports" && (<ReportsPage sales={sales} expenses={expenses} totals={totals} />)}
        {tab === "Settings" && (<SettingsPage clearAll={() => {
          if (confirm("This will clear all local data. Continue?")) { localStorage.clear(); location.reload(); }
        }} />)}
      </main>
    </div>
  );
}

function Card({ children, className = "" }) {
  return <div className={`bg-white rounded-2xl shadow-sm border p-4 ${className}`}>{children}</div>;
}
function Stat({ icon: Icon, label, value }) {
  return (
    <Card>
      <div className="flex items-center gap-3">
        <div className="p-2 rounded-xl bg-gray-50 border"><Icon className="w-5 h-5" /></div>
        <div>
          <div className="text-sm text-gray-600">{label}</div>
          <div className="text-xl font-semibold">{value}</div>
        </div>
      </div>
    </Card>
  );
}

function Dashboard({ totals, aiInsights, lowStock }) {
  return (
    <div className="grid gap-4">
      {lowStock.length > 0 && (
        <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }}>
          <Card className="border-amber-300">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 mt-0.5" />
              <div>
                <div className="font-medium">AI Alerts</div>
                <ul className="list-disc ml-5 mt-1 text-sm text-gray-700">
                  {aiInsights.map((t, i) => (<li key={i}>{t}</li>))}
                </ul>
              </div>
            </div>
          </Card>
        </motion.div>
      )}

      <div className="grid sm:grid-cols-3 gap-3">
        <Stat icon={DollarSign} label="Revenue" value={`৳ ${totals.revenue.toFixed(2)}`} />
        <Stat icon={PieChart} label="Expense" value={`৳ ${totals.expense.toFixed(2)}`} />
        <Stat icon={TrendingUp} label="Profit" value={`৳ ${totals.profit.toFixed(2)}`} />
      </div>

      <Card>
        <div className="text-sm text-gray-600">Quick tips</div>
        <div className="mt-2 text-gray-800 text-sm">
          • Add a few sales to see top-selling products.<br />
          • Update stock levels to unlock low-stock warnings.
        </div>
      </Card>
    </div>
  );
}

function SalesPage({ sales, setSales }) {
  const [form, setForm] = useState({
    date: new Date().toISOString().slice(0, 10),
    product: PRODUCTS[0],
    qty: 1,
    unitPrice: 0,
  });

  const addSale = () => {
    if (!form.qty || !form.unitPrice) return alert("Please enter quantity and unit price.");
    const entry = { id: crypto.randomUUID(), ...form, qty: Number(form.qty), unitPrice: Number(form.unitPrice) };
    setSales((s) => [entry, ...s]);
    setForm({ ...form, qty: 1, unitPrice: 0 });
  };
  const del = (id) => setSales((s) => s.filter((x) => x.id !== id));
  const total = sales.reduce((sum, r) => sum + r.qty * r.unitPrice, 0);

  return (
    <div className="grid gap-4">
      <Card>
        <div className="font-medium mb-3">Add Sale</div>
        <div className="grid sm:grid-cols-5 gap-3">
          <input type="date" className="border rounded-xl px-3 py-2" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
          <select className="border rounded-xl px-3 py-2" value={form.product} onChange={(e) => setForm({ ...form, product: e.target.value })}>
            {PRODUCTS.map((p) => (<option key={p} value={p}>{p}</option>))}
          </select>
          <input type="number" className="border rounded-xl px-3 py-2" placeholder="Qty" value={form.qty} onChange={(e) => setForm({ ...form, qty: e.target.value })} />
          <input type="number" className="border rounded-xl px-3 py-2" placeholder="Unit Price" value={form.unitPrice} onChange={(e) => setForm({ ...form, unitPrice: e.target.value })} />
          <button onClick={addSale} className="inline-flex items-center justify-center gap-2 border rounded-xl px-3 py-2 bg-gray-900 text-white hover:opacity-90"><PlusCircle className="w-4 h-4"/>Add</button>
        </div>
      </Card>

      <Card>
        <div className="flex items-center justify-between mb-3">
          <div className="font-medium">Recent Sales</div>
          <div className="text-sm">Total: ৳ {total.toFixed(2)}</div>
        </div>
        <div className="overflow-auto -mx-2">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="text-left text-gray-500">
                <th className="px-2 py-2">Date</th>
                <th className="px-2 py-2">Product</th>
                <th className="px-2 py-2">Qty</th>
                <th className="px-2 py-2">Unit Price</th>
                <th className="px-2 py-2">Subtotal</th>
                <th className="px-2 py-2">Action</th>
              </tr>
            </thead>
            <tbody>
              {sales.map((r) => (
                <tr key={r.id} className="border-t">
                  <td className="px-2 py-2">{r.date}</td>
                  <td className="px-2 py-2">{r.product}</td>
                  <td className="px-2 py-2">{r.qty}</td>
                  <td className="px-2 py-2">৳ {r.unitPrice.toFixed(2)}</td>
                  <td className="px-2 py-2">৳ {(r.qty * r.unitPrice).toFixed(2)}</td>
                  <td className="px-2 py-2">
                    <button onClick={() => del(r.id)} className="p-1 rounded-lg border hover:bg-gray-50"><Trash2 className="w-4 h-4"/></button>
                  </td>
                </tr>
              ))}
              {sales.length === 0 && (
                <tr><td colSpan={6} className="px-2 py-6 text-center text-gray-500">No sales recorded yet.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

function ExpensesPage({ expenses, setExpenses }) {
  const [form, setForm] = useState({
    date: new Date().toISOString().slice(0, 10),
    category: "Raw Materials",
    amount: 0,
    note: "",
  });

  const addExpense = () => {
    if (!form.amount) return alert("Please enter an amount.");
    const entry = { id: crypto.randomUUID(), ...form, amount: Number(form.amount) };
    setExpenses((s) => [entry, ...s]);
    setForm({ ...form, amount: 0, note: "" });
  };
  const del = (id) => setExpenses((s) => s.filter((x) => x.id !== id));
  const total = expenses.reduce((sum, e) => sum + e.amount, 0);

  return (
    <div className="grid gap-4">
      <Card>
        <div className="font-medium mb-3">Add Expense</div>
        <div className="grid sm:grid-cols-5 gap-3">
          <input type="date" className="border rounded-xl px-3 py-2" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
          <select className="border rounded-xl px-3 py-2" value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
            <option>Raw Materials</option>
            <option>Gas/Electricity</option>
            <option>Salary</option>
            <option>Rent</option>
            <option>Transport</option>
            <option>Other</option>
          </select>
          <input type="number" className="border rounded-xl px-3 py-2" placeholder="Amount" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} />
          <input type="text" className="border rounded-xl px-3 py-2" placeholder="Note (optional)" value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} />
          <button onClick={addExpense} className="inline-flex items-center justify-center gap-2 border rounded-xl px-3 py-2 bg-gray-900 text-white hover:opacity-90"><PlusCircle className="w-4 h-4"/>Add</button>
        </div>
      </Card>

      <Card>
        <div className="flex items-center justify-between mb-3">
          <div className="font-medium">Recent Expenses</div>
          <div className="text-sm">Total: ৳ {total.toFixed(2)}</div>
        </div>
        <div className="overflow-auto -mx-2">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="text-left text-gray-500">
                <th className="px-2 py-2">Date</th>
                <th className="px-2 py-2">Category</th>
                <th className="px-2 py-2">Amount</th>
                <th className="px-2 py-2">Note</th>
                <th className="px-2 py-2">Action</th>
              </tr>
            </thead>
            <tbody>
              {expenses.map((r) => (
                <tr key={r.id} className="border-t">
                  <td className="px-2 py-2">{r.date}</td>
                  <td className="px-2 py-2">{r.category}</td>
                  <td className="px-2 py-2">৳ {r.amount.toFixed(2)}</td>
                  <td className="px-2 py-2">{r.note}</td>
                  <td className="px-2 py-2">
                    <button onClick={() => del(r.id)} className="p-1 rounded-lg border hover:bg-gray-50"><Trash2 className="w-4 h-4"/></button>
                  </td>
                </tr>
              ))}
              {expenses.length === 0 && (
                <tr><td colSpan={5} className="px-2 py-6 text-center text-gray-500">No expenses recorded yet.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

function StockRow({ label, value, onChange }) {
  const [v, setV] = useState(value ?? 0);
  useEffect(() => setV(value ?? 0), [value]);
  return (
    <div className="grid grid-cols-[1fr_auto_auto] items-center gap-2">
      <div className="truncate">{label}</div>
      <input type="number" className="border rounded-xl px-3 py-2 w-28" value={v} onChange={(e) => setV(Number(e.target.value))} />
      <button onClick={() => onChange(v)} className="px-2 py-2 border rounded-xl bg-gray-900 text-white hover:opacity-90">Save</button>
    </div>
  );
}

function StockPage({ stock, setStock }) {
  const low = MATERIALS.filter((m) => (stock[m.key] ?? 0) <= m.threshold);
  return (
    <div className="grid gap-4">
      {low.length > 0 && (
        <Card className="border-amber-300">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 mt-0.5"/>
            <div>
              <div className="font-medium">Low Stock</div>
              <div className="text-sm text-gray-700">{low.map((m) => m.label.split(" ")[0]).join(", ")} — please reorder soon.</div>
            </div>
          </div>
        </Card>
      )}

      <Card>
        <div className="font-medium mb-3">Update Stock</div>
        <div className="grid sm:grid-cols-2 gap-3">
          {MATERIALS.map((m) => (
            <StockRow key={m.key} label={m.label} value={stock[m.key]} onChange={(val) => setStock((s) => ({ ...s, [m.key]: Number(val) }))} />
          ))}
        </div>
      </Card>
    </div>
  );
}

function ReportsPage({ sales, expenses, totals }) {
  const exportJSON = () => {
    const payload = { sales, expenses, totals, exportedAt: new Date().toISOString() };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `royal-bakery-report-${new Date().toISOString().slice(0,10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const byProduct = PRODUCTS.map((p) => {
    const qty = sales.filter((s) => s.product === p).reduce((n, s) => n + s.qty, 0);
    const rev = sales.filter((s) => s.product === p).reduce((n, s) => n + s.qty * s.unitPrice, 0);
    return { product: p, qty, revenue: rev };
  });

  return (
    <div className="grid gap-4">
      <Card>
        <div className="font-medium mb-2">Profit & Loss</div>
        <div className="grid sm:grid-cols-3 gap-3">
          <Stat icon={DollarSign} label="Revenue" value={`৳ ${totals.revenue.toFixed(2)}`} />
          <Stat icon={PieChart} label="Expense" value={`৳ ${totals.expense.toFixed(2)}`} />
          <Stat icon={TrendingUp} label="Profit" value={`৳ ${totals.profit.toFixed(2)}`} />
        </div>
      </Card>

      <Card>
        <div className="flex items-center justify-between mb-2">
          <div className="font-medium">Sales by Product</div>
          <button onClick={exportJSON} className="inline-flex items-center gap-2 border rounded-xl px-3 py-2 bg-white hover:bg-gray-50"><Download className="w-4 h-4"/>Export JSON</button>
        </div>
        <div className="overflow-auto -mx-2">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="text-left text-gray-500">
                <th className="px-2 py-2">Product</th>
                <th className="px-2 py-2">Qty</th>
                <th className="px-2 py-2">Revenue</th>
              </tr>
            </thead>
            <tbody>
              {byProduct.map((r) => (
                <tr key={r.product} className="border-t">
                  <td className="px-2 py-2">{r.product}</td>
                  <td className="px-2 py-2">{r.qty}</td>
                  <td className="px-2 py-2">৳ {r.revenue.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <Card>
        <div className="font-medium mb-1">How to read this</div>
        <ul className="list-disc ml-5 text-sm text-gray-700">
          <li>Profit = Revenue − Expense.</li>
          <li>Use Stock tab to maintain ingredient levels and get low-stock alerts.</li>
          <li>Export JSON to share raw data (you can convert to Excel/Google Sheets later).</li>
        </ul>
      </Card>
    </div>
  );
}

function SettingsPage({ clearAll }) {
  return (
    <div className="grid gap-4">
      <Card>
        <div className="font-medium mb-2">Account & Data</div>
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
          <button onClick={clearAll} className="inline-flex items-center gap-2 border rounded-xl px-3 py-2 bg-white hover:bg-gray-50"><Trash2 className="w-4 h-4"/>Clear all local data</button>
        </div>
        <p className="text-sm text-gray-600 mt-3">This prototype runs entirely in your browser. Sign-in and cloud sync will be added in a hosted version.</p>
      </Card>

      <Card>
        <div className="font-medium mb-2">Next Up (when you want)</div>
        <ul className="list-disc ml-5 text-sm text-gray-700">
          <li>Google Sign-In (real auth) & cloud backup</li>
          <li>PDF reports and Google Sheets export</li>
          <li>Smarter AI: demand forecasting, purchase recommendations</li>
        </ul>
      </Card>
    </div>
  );
}
